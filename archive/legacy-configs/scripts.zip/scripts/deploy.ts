/**
 * Story Protocol Smart Contract Deployment Script
 * 
 * This script deploys all Millionaire Resilience contracts to Story Protocol
 * Network: Story Mainnet (Chain ID: 1514) or Testnet (Chain ID: 1315)
 * 
 * Prerequisites:
 * - Private key set in environment
 * - Sufficient $IP tokens for gas
 * - Foundry or Hardhat installed
 */

import { ethers } from "ethers";
import * as fs from "fs";
import * as path from "path";

// Configuration
const STORY_MAINNET_RPC = "https://mainnet.storyrpc.io";
const STORY_TESTNET_RPC = "https://aeneid.storyrpc.io";
const STORY_MAINNET_CHAIN_ID = 1514;
const STORY_TESTNET_CHAIN_ID = 1315;

// Story Protocol Core Contract Addresses (Mainnet)
const STORY_CORE_CONTRACTS = {
  ipAssetRegistry: "0x77319B4031e6eF1250907aa00018B8B1c67a244b",
  licensingModule: "0x04fbd8a2e56dd85CFD5500A4A4DfA955B9f1dE6f",
  royaltyModule: "0xD2f60c40fEbccf6311f8B47c4f2Ec6b040400086",
  spg: "0x69415CE984A79a3Cfbe3F51024C63b6C107331e3",
};

// Millionaire Resilience IPID
const MR_STORY_IPID = "0x98971c660ac20880b60F86Cc3113eBd979eb3aAE";

interface DeploymentResult {
  contractName: string;
  address: string;
  txHash: string;
  deployer: string;
  timestamp: number;
  constructorArgs: any[];
  gasUsed: string;
}

interface DeploymentManifest {
  network: string;
  chainId: number;
  timestamp: number;
  deployments: DeploymentResult[];
  storyProtocolIPID: string;
}

/**
 * Main deployment function
 */
async function deploy(network: "mainnet" | "testnet" = "testnet"): Promise<DeploymentManifest> {
  console.log(`\n=== Millionaire Resilience Smart Contract Deployment ===`);
  console.log(`Network: Story Protocol ${network}`);
  console.log(`Story IPID: ${MR_STORY_IPID}\n`);

  // Setup provider
  const rpcUrl = network === "mainnet" ? STORY_MAINNET_RPC : STORY_TESTNET_RPC;
  const chainId = network === "mainnet" ? STORY_MAINNET_CHAIN_ID : STORY_TESTNET_CHAIN_ID;
  
  const provider = new ethers.JsonRpcProvider(rpcUrl);
  
  // Get deployer wallet from environment
  const privateKey = process.env.DEPLOYER_PRIVATE_KEY;
  if (!privateKey) {
    throw new Error("DEPLOYER_PRIVATE_KEY not set in environment");
  }
  
  const wallet = new ethers.Wallet(privateKey, provider);
  const deployerAddress = await wallet.getAddress();
  
  console.log(`Deployer: ${deployerAddress}`);
  
  // Check balance
  const balance = await provider.getBalance(deployerAddress);
  console.log(`Balance: ${ethers.formatEther(balance)} IP\n`);
  
  if (balance === BigInt(0)) {
    throw new Error("Deployer has no balance. Get testnet tokens from https://faucet.story.foundation/");
  }

  const deployments: DeploymentResult[] = [];

  // Deploy contracts in order
  console.log("1. Deploying MillionaireResilience...");
  const mrResult = await deployContract(
    wallet,
    "MillionaireResilience",
    [],
    getContractBytecode("MillionaireResilience")
  );
  deployments.push(mrResult);
  console.log(`   Deployed at: ${mrResult.address}\n`);

  console.log("2. Deploying SlapsStreaming...");
  const slapsResult = await deployContract(
    wallet,
    "SlapsStreaming",
    [],
    getContractBytecode("SlapsStreaming")
  );
  deployments.push(slapsResult);
  console.log(`   Deployed at: ${slapsResult.address}\n`);

  console.log("3. Deploying SlapsSPV...");
  const spvArgs = [
    "Slaps Music IP SPV",
    "Investment vehicle for Slaps streaming platform music IP royalties",
    ethers.parseEther("1000"), // 1000 ETH target raise
    ethers.parseEther("0.1"),  // 0.1 ETH minimum investment
    365 // 365 days duration
  ];
  const spvResult = await deployContract(
    wallet,
    "SlapsSPV",
    spvArgs,
    getContractBytecode("SlapsSPV")
  );
  deployments.push(spvResult);
  console.log(`   Deployed at: ${spvResult.address}\n`);

  // Note: StablecoinIPEscrow requires Morpho address which is on Ethereum
  // For Story Protocol, we would deploy a bridge-compatible version
  console.log("4. Deploying StablecoinIPEscrow (placeholder for bridge)...");
  const escrowArgs = [
    ethers.ZeroAddress // Placeholder for Morpho - would be bridge contract
  ];
  const escrowResult = await deployContract(
    wallet,
    "StablecoinIPEscrow",
    escrowArgs,
    getContractBytecode("StablecoinIPEscrow")
  );
  deployments.push(escrowResult);
  console.log(`   Deployed at: ${escrowResult.address}\n`);

  // Create deployment manifest
  const manifest: DeploymentManifest = {
    network: `story-${network}`,
    chainId,
    timestamp: Date.now(),
    deployments,
    storyProtocolIPID: MR_STORY_IPID,
  };

  // Save manifest
  const manifestPath = path.join(__dirname, `../deployments/deployment-${chainId}.json`);
  fs.mkdirSync(path.dirname(manifestPath), { recursive: true });
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  console.log(`\nDeployment manifest saved to: ${manifestPath}`);

  // Print summary
  console.log("\n=== Deployment Summary ===");
  console.log(`Network: story-${network} (Chain ID: ${chainId})`);
  console.log(`Story Protocol IPID: ${MR_STORY_IPID}`);
  console.log("\nContracts:");
  deployments.forEach(d => {
    console.log(`  ${d.contractName}: ${d.address}`);
  });

  return manifest;
}

/**
 * Deploy a single contract
 */
async function deployContract(
  wallet: ethers.Wallet,
  name: string,
  constructorArgs: any[],
  bytecode: string
): Promise<DeploymentResult> {
  const factory = new ethers.ContractFactory([], bytecode, wallet);
  
  const contract = await factory.deploy(...constructorArgs, {
    gasLimit: 5000000,
  });
  
  const receipt = await contract.deploymentTransaction()?.wait();
  
  return {
    contractName: name,
    address: await contract.getAddress(),
    txHash: receipt?.hash || "",
    deployer: await wallet.getAddress(),
    timestamp: Date.now(),
    constructorArgs,
    gasUsed: receipt?.gasUsed?.toString() || "0",
  };
}

/**
 * Get compiled contract bytecode
 * In production, this would read from compiled artifacts
 */
function getContractBytecode(contractName: string): string {
  // Placeholder - in actual deployment, read from compiled artifacts
  const artifactPath = path.join(__dirname, `../artifacts/${contractName}.json`);
  
  if (fs.existsSync(artifactPath)) {
    const artifact = JSON.parse(fs.readFileSync(artifactPath, "utf-8"));
    return artifact.bytecode;
  }
  
  // Return placeholder for demonstration
  console.log(`   Note: ${contractName} bytecode would be loaded from compiled artifacts`);
  return "0x";
}

/**
 * Verify contracts on Story Protocol block explorer
 */
async function verifyContracts(manifest: DeploymentManifest): Promise<void> {
  console.log("\n=== Contract Verification ===");
  
  const verifierUrl = "https://explorer.story.foundation/api/";
  
  for (const deployment of manifest.deployments) {
    console.log(`Verifying ${deployment.contractName}...`);
    
    // In production, use actual verification API
    // Example using foundry:
    // forge verify-contract --chain-id 1514 --verifier blockscout --verifier-url ${verifierUrl} ${address} ${contractName}
    
    console.log(`   Would verify at: ${verifierUrl}`);
  }
}

/**
 * Register IP assets with Story Protocol
 */
async function registerIPAssets(
  wallet: ethers.Wallet,
  manifest: DeploymentManifest
): Promise<void> {
  console.log("\n=== Story Protocol IP Registration ===");
  
  const ipAssetRegistry = new ethers.Contract(
    STORY_CORE_CONTRACTS.ipAssetRegistry,
    [
      "function register(address nftContract, uint256 tokenId, string metadata) external returns (address ipId)",
      "function isRegistered(address ipId) external view returns (bool)",
    ],
    wallet
  );
  
  // Check if already registered
  const isRegistered = await ipAssetRegistry.isRegistered(MR_STORY_IPID);
  
  if (isRegistered) {
    console.log(`IP Asset ${MR_STORY_IPID} already registered with Story Protocol`);
  } else {
    console.log("IP Asset would be registered here...");
  }
}

/**
 * Setup Morpho integration for stablecoin loans
 */
async function setupMorphoIntegration(): Promise<void> {
  console.log("\n=== Morpho DeFi Integration Setup ===");
  
  const morphoBlue = "0xBBBBBbbBBb9cC5e90e3b3Af64bdAF62C37EEFFCb";
  
  console.log("Morpho Blue Address:", morphoBlue);
  console.log("Supported Markets:");
  console.log("  - USDC/wstETH");
  console.log("  - USDC/WBTC");
  console.log("  - DAI/ETH");
  
  console.log("\nTo query Morpho markets, use GraphQL API:");
  console.log("  Endpoint: https://api.morpho.org/graphql");
}

/**
 * Setup Centrifuge RWA integration
 */
async function setupCentrifugeIntegration(): Promise<void> {
  console.log("\n=== Centrifuge RWA Integration Setup ===");
  
  console.log("Centrifuge API Endpoint: https://api.centrifuge.io");
  console.log("\nSupported chains for liquidity:");
  console.log("  - Ethereum Mainnet");
  console.log("  - Coinbase Base");
  console.log("  - Arbitrum");
  console.log("  - Avalanche");
  
  console.log("\nTo create a tokenized credit pool, visit:");
  console.log("  https://app.centrifuge.io");
}

// Run deployment if executed directly
if (require.main === module) {
  const network = (process.argv[2] as "mainnet" | "testnet") || "testnet";
  
  deploy(network)
    .then(async (manifest) => {
      await setupMorphoIntegration();
      await setupCentrifugeIntegration();
      console.log("\n=== Deployment Complete ===");
    })
    .catch((error) => {
      console.error("Deployment failed:", error);
      process.exit(1);
    });
}

export { deploy, verifyContracts, registerIPAssets };
